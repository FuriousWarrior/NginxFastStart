## GOLD SPONSORS

* Edgio
* Google
* Microsoft
* Nginx (Part of F5)
* United Security Providers
* VMWare

## SILVER SPONSORS

* Bug Bounty Switzerland

